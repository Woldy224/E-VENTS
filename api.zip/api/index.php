<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

/*
|--------------------------------------------------------------------------
| Get Request Path
|--------------------------------------------------------------------------
*/

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// retire tout bagay anvan index.php
$path = explode('index.php', $path);
$path = isset($path[1]) ? $path[1] : '/';

$path = '/' . trim($path, '/');

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
*/

$routes = [
    '/auth' => 'auth.php',
    '/events' => 'events.php',
    '/proposals' => 'proposals.php',
    '/tickets' => 'tickets.php',
];

foreach ($routes as $route => $file) {
    if ($path === $route || strpos($path, $route . '/') === 0) {
        require_once __DIR__ . '/' . $file;
        exit();
    }
}

header('Content-Type: application/json');
echo json_encode(["debug" => "USER INSERTED"]);
exit;
echo json_encode([
    "name" => "Ayiti Events API",
    "version" => "1.0.0",
    "message" => "Endpoint not found",
    "available_endpoints" => [
        "/api/auth?action=register" => "POST - Register user",
        "/api/auth?action=login" => "POST - Login user",
        "/api/auth?action=admin-login" => "POST - Admin login",
        "/api/auth?action=logout" => "POST - Logout",
        "/api/auth?action=me" => "GET - Get current user",
        "/api/events?action=list" => "GET - List events",
        "/api/events?action=create" => "POST - Create event (admin)",
        "/api/events?action=update&id=X" => "PUT - Update event (admin)",
        "/api/events?action=delete&id=X" => "DELETE - Delete event (admin)",
        "/api/proposals?action=submit" => "POST - Submit proposal",
        "/api/proposals?action=list" => "GET - List proposals (admin)",
        "/api/proposals?action=approve&id=X" => "POST - Approve proposal (admin)",
        "/api/proposals?action=reject&id=X" => "POST - Reject proposal (admin)",
        "/api/tickets?action=purchase" => "POST - Purchase tickets",
        "/api/tickets?action=my-tickets" => "GET - Get user tickets"
    ]
]);
